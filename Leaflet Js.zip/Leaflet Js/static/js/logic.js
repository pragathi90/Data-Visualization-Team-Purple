
var streets = L.tileLayer("https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token={accessToken}", {
    attribution: "Map data &copy; <a href=\"https://www.openstreetmap.org/\">OpenStreetMap</a> contributors, <a href=\"https://creativecommons.org/licenses/by-sa/2.0/\">CC-BY-SA</a>, Imagery © <a href=\"https://www.mapbox.com/\">Mapbox</a>",
    maxZoom: 18,
    id: "mapbox.streets",
    accessToken: API_KEY
});

var highContrast = L.tileLayer("https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token={accessToken}", {
    attribution: "Map data &copy; <a href=\"https://www.openstreetmap.org/\">OpenStreetMap</a> contributors, <a href=\"https://creativecommons.org/licenses/by-sa/2.0/\">CC-BY-SA</a>, Imagery © <a href=\"https://www.mapbox.com/\">Mapbox</a>",
    maxZoom: 18,
    id: "mapbox.high-contrast",
    accessToken: API_KEY
});

var comic = L.tileLayer("https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token={accessToken}", {
    attribution: "Map data &copy; <a href=\"https://www.openstreetmap.org/\">OpenStreetMap</a> contributors, <a href=\"https://creativecommons.org/licenses/by-sa/2.0/\">CC-BY-SA</a>, Imagery © <a href=\"https://www.mapbox.com/\">Mapbox</a>",
    maxZoom: 18,
    id: "mapbox.comic",
    accessToken: API_KEY
});

var url = "/jobs_data";

d3.json(url, function (response) {

    var heatArray = [];
    var markers = L.markerClusterGroup();

    for (var i = 0; i < response.length; i++) {

        markers.addLayer(L.marker([response[i].lat, response[i].lng])
        .bindPopup("<h3><strong>" + response[i].company + "</strong></h3> <hr> <h4>" + response[i].position + "</h4>"));
                
        heatArray.push([response[i].lat, response[i].lng]);      
    };

    console.log(markers);

        var heat = L.heatLayer(heatArray, {
        radius: 50,
        blur: 35
    });

    var overlayMaps = {
        "Markers": markers,
        "Heatmap": heat
    };

    var baseMaps = {
        "Standard": streets,
        "Contrast": highContrast,
        "Funtimes": comic
    };

    var myMap = L.map("map", {
        center: [39.868938, -98.586317],
        zoom: 5,
        layers: [streets, markers]
    });

    L.control.layers(baseMaps, overlayMaps, {
    }).addTo(myMap);

});